import os

class Config(object):
    API_ID = int(os.environ.get("APP_ID", "27189014"))
    API_HASH = os.environ.get("API_HASH", "8c3f19dc3515be24c6ce0115b9704174")
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "5907952040:AAGmyyUVRjBTyEar8myDV7Oa_Id8nRKPhhk")
    STRING_SESSION = os.environ.get("STRING_SESSION", "1AZWarzQBuyNeI_o741nSrU6uVOfWx8jyn7J0MWFIjMrI0CKi0j_06GBbTzmsNdhvXyz8Ryhmiu4QRLpejSYX95fYh7CjeO9Ip7VjpYuXizMiTvq0wuHozZEuWW8o6WHJPRpgQE9fjO8Pz5QnxYG1tuJ2cpyrGKsBtNeqsSSqommKzTgn1yYqUvOJQw388U2gPe28V3zgFpOV8OtxyZf_pVksUy_r43poW4a5k6W35tPUpIm8jHmnAyx-xPXBbcI6j1fJI2wd6KQeG6_TITO6PJNRAIcgXkuQua1Bvb61YxM2DSipeTLbsQuSb33ZH7OmUYFRGMlGtB7cPmdOXUBAx5Pkp2YMDzg=")
    HEROKU_MODE = os.environ.get("HEROKU_MODE", None)
    BOT_USERNAME = os.environ.get("BOT_USERNAME", "MdzMusic2Bot")
    SUPPORT = os.environ.get("SUPPORT", "gringomdz")
    CHANNEL = os.environ.get("CHANNEL", "mdzup")
    START_IMG = os.environ.get("START_IMG", "https://telegra.ph/file/35a7b5d9f1f2605c9c0d3.png")
    CMD_IMG = os.environ.get("CMD_IMG", "https://telegra.ph/file/66518ed54301654f0b126.png")
